@extends('layouts.layout')
@section('content')
<div class="card">
    <div class="card-title">
        <h3>DASHBOARD</h3>
    </div>
</div>
@endsection
